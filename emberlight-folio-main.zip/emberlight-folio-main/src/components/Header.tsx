import { NavLink } from "react-router-dom";
import { ThemeToggle } from "./ThemeToggle";

export const Header = () => {
  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/about", label: "About" },
    { to: "/contacts", label: "Contacts" },
    { to: "/ideas", label: "Ideas" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <h1 className="font-serif text-2xl md:text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Creative Mind
            </h1>
            <p className="text-sm text-muted-foreground">Personal Blog & Portfolio</p>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `font-medium transition-all duration-300 relative group ${
                    isActive
                      ? "text-primary"
                      : "text-foreground hover:text-primary"
                  }`
                }
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-primary transition-all duration-300 group-hover:w-full"></span>
              </NavLink>
            ))}
          </nav>

          <ThemeToggle />
        </div>

        {/* Mobile Navigation */}
        <nav className="md:hidden flex gap-4 mt-4 justify-center border-t border-border pt-4">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `text-sm font-medium transition-all duration-300 ${
                  isActive
                    ? "text-primary"
                    : "text-foreground hover:text-primary"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};
