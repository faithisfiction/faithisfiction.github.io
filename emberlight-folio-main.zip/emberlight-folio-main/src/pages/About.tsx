import { Card, CardContent } from "@/components/ui/card";
import { Code2, Palette, Lightbulb, Heart } from "lucide-react";

const About = () => {
  const skills = [
    {
      icon: Code2,
      title: "Development",
      description: "Building modern web applications with React, TypeScript, and cutting-edge technologies.",
    },
    {
      icon: Palette,
      title: "Design",
      description: "Creating beautiful, intuitive interfaces that users love to interact with.",
    },
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "Always exploring new ideas and pushing the boundaries of what's possible.",
    },
    {
      icon: Heart,
      title: "Passion",
      description: "Dedicated to crafting exceptional digital experiences with attention to detail.",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <div className="container mx-auto px-4 py-16 md:py-24">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-6 bg-gradient-primary bg-clip-text text-transparent">
            About Me
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            I'm a passionate creator who believes in the power of design and technology 
            to make the world a better place. With a focus on clean code and beautiful 
            interfaces, I strive to build experiences that delight users.
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto mb-16">
          {skills.map((skill, index) => {
            const Icon = skill.icon;
            return (
              <Card key={index} className="group hover:shadow-card-hover transition-all duration-300 border-border">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-gradient-primary group-hover:shadow-glow transition-all duration-300">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-serif text-xl font-bold mb-2">{skill.title}</h3>
                      <p className="text-muted-foreground">{skill.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Personal Statement */}
        <div className="max-w-3xl mx-auto">
          <Card className="bg-card border-border shadow-card">
            <CardContent className="p-8 md:p-12">
              <h2 className="font-serif text-2xl md:text-3xl font-bold mb-6 text-center">
                My Philosophy
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  I believe that great design is not just about aesthetics—it's about solving 
                  real problems and creating meaningful connections between people and technology.
                </p>
                <p>
                  Every project is an opportunity to learn something new, to push creative 
                  boundaries, and to make a positive impact. I approach each challenge with 
                  curiosity, dedication, and a commitment to excellence.
                </p>
                <p>
                  When I'm not coding or designing, you'll find me exploring new technologies, 
                  reading about the latest trends, or simply enjoying the creative process 
                  in all its forms.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default About;
