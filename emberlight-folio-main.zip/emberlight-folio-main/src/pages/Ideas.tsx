import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Rocket, Zap, Target } from "lucide-react";

const Ideas = () => {
  const ideas = [
    {
      icon: Sparkles,
      title: "AI-Powered Design Assistant",
      description: "Imagine a tool that learns your design preferences and suggests layouts, color schemes, and typography combinations in real-time.",
      tags: ["AI", "Design", "Innovation"],
      status: "Exploring",
    },
    {
      icon: Rocket,
      title: "Sustainable Tech Initiative",
      description: "Building applications that prioritize energy efficiency and carbon footprint reduction without compromising performance.",
      tags: ["Sustainability", "Web Performance"],
      status: "In Progress",
    },
    {
      icon: Zap,
      title: "Real-Time Collaboration Platform",
      description: "A next-generation workspace where teams can brainstorm, design, and develop together seamlessly, regardless of location.",
      tags: ["Collaboration", "Real-time"],
      status: "Concept",
    },
    {
      icon: Target,
      title: "Accessibility-First Framework",
      description: "Creating a comprehensive framework that makes building accessible web applications the default, not an afterthought.",
      tags: ["Accessibility", "Framework", "Inclusive Design"],
      status: "Research",
    },
  ];

  const futureGoals = [
    "Launch an open-source design system for the community",
    "Write a comprehensive guide on modern web architecture",
    "Create educational content to help aspiring developers",
    "Build tools that make technology more accessible to everyone",
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <div className="container mx-auto px-4 py-16 md:py-24">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-6 bg-gradient-primary bg-clip-text text-transparent">
            Ideas & Projects
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            A glimpse into the creative experiments and innovative projects I'm 
            exploring. Some are in progress, others are still concepts waiting 
            for the right moment to come to life.
          </p>
        </div>

        {/* Ideas Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto mb-16">
          {ideas.map((idea, index) => {
            const Icon = idea.icon;
            return (
              <Card key={index} className="group hover:shadow-card-hover transition-all duration-300 border-border">
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="p-3 rounded-lg bg-gradient-primary group-hover:shadow-glow transition-all duration-300">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <Badge variant="outline" className="border-primary text-primary">
                      {idea.status}
                    </Badge>
                  </div>
                  <h3 className="font-serif text-xl md:text-2xl font-bold mb-2">
                    {idea.title}
                  </h3>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{idea.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {idea.tags.map((tag, tagIndex) => (
                      <Badge key={tagIndex} className="bg-secondary text-secondary-foreground">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Future Goals */}
        <div className="max-w-3xl mx-auto">
          <Card className="bg-card border-border shadow-card">
            <CardContent className="p-8 md:p-12">
              <h2 className="font-serif text-2xl md:text-3xl font-bold mb-8 text-center">
                Future Aspirations
              </h2>
              <div className="space-y-4">
                {futureGoals.map((goal, index) => (
                  <div key={index} className="flex items-start gap-4 group">
                    <div className="p-2 rounded-full bg-gradient-accent flex-shrink-0 group-hover:shadow-glow transition-all duration-300">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <p className="text-muted-foreground pt-1 group-hover:text-foreground transition-colors duration-300">
                      {goal}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Ideas;
