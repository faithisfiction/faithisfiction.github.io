import { Card, CardContent } from "@/components/ui/card";
import { Mail, MapPin, Phone, Github, Linkedin, Twitter } from "lucide-react";

const Contacts = () => {
  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "hello@creativemind.com",
      href: "mailto:hello@creativemind.com",
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+1 (555) 123-4567",
      href: "tel:+15551234567",
    },
    {
      icon: MapPin,
      label: "Location",
      value: "San Francisco, CA",
      href: "#",
    },
  ];

  const socialLinks = [
    {
      icon: Github,
      label: "GitHub",
      href: "https://github.com",
    },
    {
      icon: Linkedin,
      label: "LinkedIn",
      href: "https://linkedin.com",
    },
    {
      icon: Twitter,
      label: "Twitter",
      href: "https://twitter.com",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <div className="container mx-auto px-4 py-16 md:py-24">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-6 bg-gradient-primary bg-clip-text text-transparent">
            Get In Touch
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            I'd love to hear from you! Whether you have a question, a project idea, 
            or just want to say hello, feel free to reach out.
          </p>
        </div>

        {/* Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12">
          {contactInfo.map((contact, index) => {
            const Icon = contact.icon;
            return (
              <a
                key={index}
                href={contact.href}
                className="block group"
              >
                <Card className="h-full hover:shadow-card-hover transition-all duration-300 border-border">
                  <CardContent className="p-6 text-center">
                    <div className="inline-flex p-4 rounded-full bg-gradient-primary mb-4 group-hover:shadow-glow transition-all duration-300">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="font-serif text-lg font-bold mb-2">{contact.label}</h3>
                    <p className="text-muted-foreground group-hover:text-primary transition-colors duration-300">
                      {contact.value}
                    </p>
                  </CardContent>
                </Card>
              </a>
            );
          })}
        </div>

        {/* Social Links */}
        <div className="max-w-2xl mx-auto">
          <Card className="bg-card border-border shadow-card">
            <CardContent className="p-8">
              <h2 className="font-serif text-2xl font-bold mb-6 text-center">
                Connect With Me
              </h2>
              <div className="flex justify-center gap-6">
                {socialLinks.map((social, index) => {
                  const Icon = social.icon;
                  return (
                    <a
                      key={index}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group"
                      aria-label={social.label}
                    >
                      <div className="p-3 rounded-full bg-secondary group-hover:bg-gradient-primary transition-all duration-300 group-hover:shadow-glow">
                        <Icon className="h-6 w-6 text-foreground group-hover:text-white transition-colors duration-300" />
                      </div>
                    </a>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Contacts;
