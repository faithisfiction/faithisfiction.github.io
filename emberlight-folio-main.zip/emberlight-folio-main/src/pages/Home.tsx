import { BlogCard } from "@/components/BlogCard";

const Home = () => {
  const blogPosts = [
    {
      title: "The Art of Minimalist Design",
      excerpt: "Exploring how less can truly be more in modern web design. Discover the principles that make minimalist interfaces both beautiful and functional.",
      date: "March 15, 2024",
      category: "Design",
      readTime: "5 min read",
      image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
    },
    {
      title: "Building Scalable React Applications",
      excerpt: "Best practices and patterns for creating React applications that grow with your needs. From component architecture to state management strategies.",
      date: "March 10, 2024",
      category: "Development",
      readTime: "8 min read",
      image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&q=80",
    },
    {
      title: "The Future of AI in Creative Work",
      excerpt: "How artificial intelligence is transforming the creative landscape and what it means for designers and developers in the coming years.",
      date: "March 5, 2024",
      category: "Technology",
      readTime: "6 min read",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80",
    },
    {
      title: "Typography That Speaks",
      excerpt: "Understanding the psychology behind font choices and how typography can elevate your brand's voice and message.",
      date: "February 28, 2024",
      category: "Design",
      readTime: "4 min read",
      image: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=800&q=80",
    },
    {
      title: "Mastering CSS Grid Layouts",
      excerpt: "A comprehensive guide to creating responsive, flexible layouts with CSS Grid. Learn advanced techniques and practical examples.",
      date: "February 20, 2024",
      category: "Development",
      readTime: "7 min read",
      image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?w=800&q=80",
    },
    {
      title: "The Power of User-Centered Design",
      excerpt: "Why putting users first leads to better products and how to implement user research in your design process effectively.",
      date: "February 15, 2024",
      category: "UX",
      readTime: "5 min read",
      image: "https://images.unsplash.com/photo-1559028012-481c04fa702d?w=800&q=80",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-serif text-4xl md:text-6xl font-bold mb-6 bg-gradient-primary bg-clip-text text-transparent">
            Welcome to My Creative Space
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
            A collection of thoughts, ideas, and insights on design, development, 
            and the ever-evolving world of technology. Join me on this journey of 
            continuous learning and creative exploration.
          </p>
          <div className="flex items-center justify-center gap-4">
            <div className="h-px w-16 bg-gradient-primary"></div>
            <span className="text-accent font-semibold">Latest Articles</span>
            <div className="h-px w-16 bg-gradient-primary"></div>
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="container mx-auto px-4 pb-16 md:pb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {blogPosts.map((post, index) => (
            <BlogCard key={index} {...post} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
